%% Nominal values and used to derive p.u. values
Sn = 5000e3;         % Rated power, W
Vn = 690;            % Rated line-to-line RMS voltage, V
Vpn = Vn*sqrt(2/3);  % Rated line-to-ground voltage magnitude, V
Ipn = 2/3*Sn/Vpn;    % Rated current magnitude, A
Zb = Vpn/Ipn;        % Rated impedance, Ohm
Vdcn = 1500;         % Rated DC voltage, V


    % Grid-side
    fn = 50;             % Rated frequency, Hz
    wn = 2*pi*fn;        % Rated angular frequency, rad/s
    Lb = Zb/wn;          % Base inductance, H
    Cb = 1/(wn*Zb);      % Base capacitance, F

    % Machine-side
    wrn = 1.27;   % WT rated rotor speed, rad/s
    Np = 3; % Pole pairs
    Ng = 82; % gearbox ratio
    wgn = wrn*Ng; % PMSG rated rotor speed, rad/s
    Lsb = Zb/wgn/Np; % Base inductance, H
    Psin = Vpn/wgn/Np; % Base magnetic flux, Wb


%% Simulation parameters
fsw = 5e3;   % Switching frequency, Hz
Tsw = 1/fsw; % Switching period, s
fs = fsw;    % Sampling frequency, Hz
Ts = 1/fs;   % Sampling time, s
fc = fs*25;  % calculation frequency of simulink, Hz
Tc = 1/fc;   % calculation step size, s

%% System parameters

    % Grid-side
        % power grid
        Vg_phy = Vn; % phase-to-phase voltage (Vrms), V
        fg_phy = fn; % frequency, Hz

        % LCL filter is designed such that the resonace frequency is 1/5*fsw, C provides 5% reactive power, and minimum Lf + Lg requring Lf/Lg = 1
        Cf_phy = 1600e-6;         % Capacitance, F
        Lf_phy = 3.2e-5;          % Inverter-side inductance, H
        Rf_phy = Lf_phy*wn/8;     % Inductor resistance, Ohm
        Lg_phy = 3.2e-5 + 2.8e-5; % Grid-side inductance + line inductance, H
        Rg_phy = Lg_phy*wn/6;     % line resistance, Ohm

        % transform to p.u. values
        Lf = Lf_phy/Lb;
        Rf = Rf_phy/Zb;
        Cf = Cf_phy/Cb;
        Lg = Lg_phy/Lb;
        Rg = Rg_phy/Zb;

    % DC link
    Vdcst_phy = Vdcn; 
    Cdc_phy = 0.17; % DC link capacitor, F

    % Machine-side
        % PMSG
        Ls_phy = 4.3e-5;    % Stator inductor, H
        Rs_phy = 1.3e-3; % Parasitic resistance of stator inductor, Ohm
        Psi_phy = 1.8033;   % Magnetic flux
        Hg = 0.8;
        Jg = 2*Hg*Sn/wgn^2;
        
        % Wind turbine
        rho = 1.23;        % air density, kg/m3
        R = 63;           % wind turbine blade length, m
        Copt = 0.448;      % optimal power coefficient
        lamopt = 7;       % optimal tip speed ratio
        lamprim = 8.32;
        kwopt = 0.5*rho*pi*R^5*Copt/lamopt^3;
        c1 = 0.5;
        c2 = 100;
        c3 = 0.4;
        c4 = 0;
        c5 = 5;
        c6 = 17.3;
        xwt = 1.5;
        kwt = 0.5*rho*pi*R^3;
        d = 20; % percent of curtailment
        % transform to p.u. values
        Ls = Ls_phy/Lsb;
        Psi = Psi_phy/Psin;


%% Control parameters

    % Grid-side
        % inner current loop
        kpi = 0.16;
        kii = 8.1;

        % inner voltage loop
        kpv = 5;
        kiv = 350;
        kffi = 0.6;
        vqst = 0;

        % reactive power loop
        Qst = 0;
        Vst = 1;
        Dq = 10;
        Tq = 0.045;

        % active power loop
        wst = 1;
        Dp = 50;
        H = 0.5;
        
        
    % Machine-side
        % inner current loop
        kpis = 0.75;
        kiis = 22.8;
        isdst = 0;

        % DC voltage loop
        kpdc = 18;
        kidc = 160;

        % Wind turbine
        bst = 0; % pitch angle
        vwst = 11.4; % wind speed, m/s

    % cooperation with primary control
        dfmax = 0.01;
        prev = 0.1;
        Tprim = 0.5;
